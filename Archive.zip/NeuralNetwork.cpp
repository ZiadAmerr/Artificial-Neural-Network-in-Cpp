//
//  NeuralNetwork.cpp
//  Project
//
//  Created by Ziad Amerr on 04/12/2022.
//

#include <stdio.h>
#include <iostream>
#include <list>
#include <vector>
using namespace std;

class Arrow {
public:
    Arrow() {}
    
    Arrow(int nextNeuronId, double weight=0) {
        this->nextNeuronId = nextNeuronId;
        this->weight = weight;
    }
    
    ~Arrow() {}
    
    void setWeight(double w) {
        weight = w;
    }
    
    double getWeight() {
        return weight;
    }
    
    int getNextNeuronId() {
        return nextNeuronId;
    }

private:
    int nextNeuronId;
    double weight;
};



class Neuron {
public:
    Neuron() {
        neuronId = 0;
        layerId = 0;
        activation = 0;
    }
    
    Neuron(int neuronId, int layerId) {
        this->neuronId = neuronId;
        this->layerId = layerId;
        this->activation = 0;
    }
    
    ~Neuron() {}
    
    int getNeuronId() {
        return neuronId;
    }
    
    vector<Arrow> getArrowList() {
        return arrowList;
    }
    
    void addArrow(int nextNeuronId) {
        Arrow myArrow = Arrow(nextNeuronId, 0);
        arrowList.push_back(myArrow);
    }
    
    void printArrowList() {
        cout << '[';
        for(auto it = arrowList.begin(); it != arrowList.end(); it++)
            cout << it->getNextNeuronId() << '(' << it->getWeight() <<"), ";
        cout << ']' << endl;
    }
    
    int getLayerId() {
        return layerId;
    }

private:
    int neuronId, layerId;
    double activation;
    vector<Arrow> arrowList;
};




class NeuralNetwork {
private:
    vector<vector<Neuron>> neurons;
    
    // MUST BE VERIFIED
//    void _addNeuron(int layerIdx) {
//        int neuronId = int(neurons.at(layerIdx).size());
//        Neuron newNeuron = Neuron(neuronId, layerIdx);
//
//        if(_checkIfNeuronExists(newNeuron.getNeuronId(), layerIdx)) {
//            cout << "Neuron already exists" << endl;
//            return;
//        } else {
//            neurons.at(layerIdx).push_back(newNeuron);
//        }
//    }
    
    bool _checkIfNeuronExists(int neuronId, int layerIdx) {
        for(int i = 0; i<neurons.size(); i++)
            if(neurons.at(layerIdx).at(i).getNeuronId() == neuronId)
                return true;
        
        // If not found
        return false;
    }
    
    Neuron _getNeuron(int neuronId, int layerIdx) {
        Neuron n;
        for (int i = 0; i < neurons.size(); i++) {
            n = neurons.at(layerIdx).at(i);
            if (n.getNeuronId() == neuronId)
                return n;
        }
        
        // If not found
        cout << "Error! Neuron not found!" << endl;
        return n;
    }
    
//    bool _checkIfArrowExist(int srcNeuronId, int otherNeuronId, bool recursive=true) {
//        Neuron srcNeuron = _getNeuron(srcNeuronId, layerIdx);
//        list<Arrow> arrowList = srcNeuron.getArrowList();
//        for(auto it = arrowList.begin(); it != arrowList.end(); it++)
//            if(it->getNextNeuronId() == otherNeuronId)
//                return true;
//
//
//        if(not recursive)
//            return false;
//        else
//            return _checkIfArrowExist(otherNeuronId, srcNeuronId, false);
//    }
    
    void _connectNeurons(int prevNeuronId, int nextNeuronId, int firstLayerIdx, double weight=0) {
        bool prevNeuronExists = _checkIfNeuronExists(prevNeuronId, firstLayerIdx);
        bool nextNeuronExists = _checkIfNeuronExists(nextNeuronId, firstLayerIdx+1);
        
        if(not prevNeuronExists or not nextNeuronExists) {
            cout << "Invalid Neuron ID" << endl;
            return;
        };
        
        Neuron n1, n2;
        n1 = _getNeuron(prevNeuronId, firstLayerIdx);
        n1 = _getNeuron(nextNeuronId, firstLayerIdx+1);
        
        n1.addArrow(n2.getNeuronId());
    }
    
    void _initializeLayer(int numberOfNeurons, int layerIdx) {
        vector<Neuron> myVec;
        Neuron newNeuron;
        for(int i=0; i<numberOfNeurons; i++) {
            Neuron newNeuron = Neuron(i, layerIdx);
            myVec.push_back(newNeuron);
        }
        neurons.push_back(myVec);
    }
    
    void _connectLayers(int firstLayerId) {
        // Loop through the current layers neurons
        for(int i=0; i<neurons.at(firstLayerId).size(); i++) {
            // Connect each neuron with ALL the neurons in the next layer
            for(int j=0; j<neurons.at(firstLayerId+1).size(); j++) {
                neurons.at(firstLayerId).at(i).addArrow(neurons.at(firstLayerId+1).at(j).getNeuronId());
            };
        }
    };
    
public:
    NeuralNetwork(vector<int> neuronsPerLayer) {
        for(int i=0; i<neuronsPerLayer.size(); i++)
            _initializeLayer(neuronsPerLayer.at(i), i);
        
        for(int i=0; i<neuronsPerLayer.size()-1; i++)
            _connectLayers(i);
    }
    
    void printNetwork() {
        Neuron n;
        for(int i=0; i<neurons.size(); i++) {
            cout << "Layer " << i << endl;
            for(int j=0; j<neurons.at(i).size(); j++) {
                n = neurons.at(i).at(j);
                cout << "  N#" << n.getNeuronId() << "-->";
                n.printArrowList();
            }
            cout << endl;
        }
    }
};
